import { useState, type ReactNode } from "react"

type Screen = "home" | "results" | "seats" | "passenger" | "payment" | "confirmation"

type IconName = "arrow" | "bus" | "calendar" | "card" | "check" | "chevron" | "clock" | "download" | "location" | "person" | "seat" | "shield" | "swap"

const screenSteps: Record<Screen, number> = {
  home: 1,
  results: 2,
  seats: 3,
  passenger: 4,
  payment: 5,
  confirmation: 6,
}

const previousScreen: Partial<Record<Screen, Screen>> = {
  results: "home",
  seats: "results",
  passenger: "seats",
  payment: "passenger",
}

function Icon({
  name,
  className = "size-5",
}: {
  name: IconName
  className?: string
}) {
  const paths: Record<IconName, ReactNode> = {
    arrow: (
      <>
        <path d="m15 18-6-6 6-6" />
        <path d="M9 12h10" />
      </>
    ),
    bus: (
      <>
        <path d="M6 17h12" />
        <path d="M6 17v-9c0-2 1.5-3 6-3s6 1 6 3v9" />
        <path d="M6 11h12" />
        <path d="M8.5 8h7" />
        <circle cx="8.5" cy="17.5" r="1.5" />
        <circle cx="15.5" cy="17.5" r="1.5" />
      </>
    ),
    calendar: (
      <>
        <rect x="4" y="5" width="16" height="15" rx="2" />
        <path d="M8 3v4M16 3v4M4 10h16" />
      </>
    ),
    card: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="M3 10h18M7 15h3" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    download: (
      <>
        <path d="M12 3v12m0 0 4-4m-4 4-4-4" />
        <path d="M5 19h14" />
      </>
    ),
    location: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    person: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M5 21a7 7 0 0 1 14 0" />
      </>
    ),
    seat: (
      <>
        <path d="M7 4v8h9V7a3 3 0 0 1 3 3v8H7a3 3 0 0 1-3-3V9" />
        <path d="M7 18v2M19 18v2" />
      </>
    ),
    shield: (
      <>
        <path d="M12 3 5 6v5c0 5 3 8 7 10 4-2 7-5 7-10V6l-7-3Z" />
        <path d="m9 12 2 2 4-4" />
      </>
    ),
    swap: (
      <>
        <path d="m8 7 3-3m-3 3 3 3M16 17l-3 3m3-3-3-3" />
        <path d="M8 7h7a2 2 0 0 1 2 2v1M16 17H9a2 2 0 0 1-2-2v-1" />
      </>
    ),
  }

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

function Action({
  children,
  onClick,
  variant = "primary",
  className = "",
}: {
  children: ReactNode
  onClick: () => void
  variant?: "primary" | "secondary"
  className?: string
}) {
  const styles =
    variant === "primary"
      ? "bg-blue-600 text-white shadow-lg shadow-blue-200 hover:bg-blue-700"
      : "border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100"

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") onClick()
      }}
      className={`flex min-h-12 cursor-pointer items-center justify-center gap-2 rounded-2xl px-5 text-sm font-bold transition active:scale-[0.98] ${styles} ${className}`}
    >
      {children}
    </div>
  )
}

function Field({
  label,
  value,
  icon,
  placeholder = false,
}: {
  label: string
  value: string
  icon?: IconName
  placeholder?: boolean
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3.5 shadow-sm">
      <div className="flex items-center gap-3">
        {icon && (
          <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
            <Icon name={icon} />
          </div>
        )}
        <div className="min-w-0">
          <div className="text-xs font-semibold tracking-wide text-slate-400">
            {label}
          </div>
          <div
            className={`mt-0.5 truncate text-sm font-semibold ${
              placeholder ? "text-slate-400" : "text-slate-800"
            }`}
          >
            {value}
          </div>
        </div>
      </div>
    </div>
  )
}

function ScreenShell({
  screen,
  title,
  subtitle,
  onBack,
  children,
}: {
  screen: Screen
  title: string
  subtitle?: string
  onBack?: () => void
  children: ReactNode
}) {
  return (
    <div className="flex min-h-full flex-col">
      <div className="border-b border-slate-100 bg-white px-5 pb-5 pt-6">
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {onBack ? (
              <div
                role="button"
                aria-label="Go back"
                tabIndex={0}
                onClick={onBack}
                onKeyDown={(event) => event.key === "Enter" && onBack()}
                className="flex size-10 cursor-pointer items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
              >
                <Icon name="arrow" />
              </div>
            ) : (
              <div className="flex size-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-200">
                <Icon name="bus" />
              </div>
            )}
            <div>
              <div className="text-xl font-extrabold tracking-tight text-slate-900">
                {title}
              </div>
              {subtitle && (
                <div className="mt-0.5 text-xs font-medium text-slate-500">
                  {subtitle}
                </div>
              )}
            </div>
          </div>
          <div className="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700">
            {screenSteps[screen]}/6
          </div>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
          <div
            className={`h-full rounded-full bg-blue-600 transition-all ${
              screenSteps[screen] === 1
                ? "w-1/6"
                : screenSteps[screen] === 2
                  ? "w-2/6"
                  : screenSteps[screen] === 3
                    ? "w-3/6"
                    : screenSteps[screen] === 4
                      ? "w-4/6"
                      : screenSteps[screen] === 5
                        ? "w-5/6"
                        : "w-full"
            }`}
          />
        </div>
      </div>
      <div className="flex flex-1 flex-col px-5 py-5">{children}</div>
    </div>
  )
}

function HomeScreen({ navigate }: { navigate: (screen: Screen) => void }) {
  return (
    <ScreenShell
      screen="home"
      title="Bus Ticket Booking"
      subtitle="Plan your journey with ease"
    >
      <div className="mb-5 rounded-3xl bg-blue-600 p-5 text-white shadow-xl shadow-blue-200">
        <div className="mb-5 flex items-start justify-between">
          <div>
            <div className="text-xs font-semibold text-blue-100">
              Your route
            </div>
            <div className="mt-1 text-lg font-bold">Chennai to Bangalore</div>
          </div>
          <div className="flex size-11 items-center justify-center rounded-2xl bg-white/15">
            <Icon name="bus" className="size-6" />
          </div>
        </div>
        <div className="flex items-center gap-3 text-xs font-medium text-blue-100">
          <Icon name="shield" className="size-4" />
          Safe travel · Easy booking · Best fares
        </div>
      </div>

      <div className="relative space-y-3">
        <Field label="FROM" value="Chennai" icon="location" />
        <div className="absolute right-5 top-12 z-10 flex size-9 items-center justify-center rounded-full border-4 border-slate-50 bg-white text-blue-600 shadow-md">
          <Icon name="swap" className="size-4" />
        </div>
        <Field label="TO" value="Bangalore" icon="location" />
        <Field label="JOURNEY DATE" value="10 October 2026" icon="calendar" />
      </div>

      <Action onClick={() => navigate("results")} className="mt-auto">
        Search Buses
        <Icon name="chevron" className="size-4" />
      </Action>
    </ScreenShell>
  )
}

function ResultsScreen({ navigate }: { navigate: (screen: Screen) => void }) {
  const buses = [
    {
      name: "SETC Express",
      time: "09:00 AM",
      arrival: "04:00 PM",
      fare: "₹650",
      duration: "7h 00m",
    },
    {
      name: "TNSTC Express",
      time: "10:00 AM",
      arrival: "05:30 PM",
      fare: "₹550",
      duration: "7h 30m",
    },
  ]

  return (
    <ScreenShell
      screen="results"
      title="Available Buses"
      subtitle="Chennai to Bangalore · 10 Oct"
      onBack={() => navigate("home")}
    >
      <div className="mb-4 flex items-center justify-between">
        <div className="text-sm font-bold text-slate-800">2 buses found</div>
        <div className="rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">
          Best prices
        </div>
      </div>
      <div className="space-y-4">
        {buses.map((bus, index) => (
          <div
            key={bus.name}
            className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex size-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                  <Icon name="bus" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">{bus.name}</div>
                  <div className="mt-0.5 text-xs font-medium text-slate-400">
                    AC Seater · {index === 0 ? "4.6" : "4.4"} rating
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-extrabold text-slate-900">
                  {bus.fare}
                </div>
                <div className="text-xs text-slate-400">per seat</div>
              </div>
            </div>
            <div className="my-4 flex items-center">
              <div>
                <div className="text-sm font-bold text-slate-800">
                  {bus.time}
                </div>
                <div className="text-xs text-slate-400">Chennai</div>
              </div>
              <div className="mx-3 flex flex-1 items-center gap-2">
                <div className="size-2 rounded-full border-2 border-blue-500" />
                <div className="h-px flex-1 border-t border-dashed border-slate-300" />
                <div className="flex items-center gap-1 text-xs font-medium text-slate-400">
                  <Icon name="clock" className="size-3.5" />
                  {bus.duration}
                </div>
                <div className="h-px flex-1 border-t border-dashed border-slate-300" />
                <div className="size-2 rounded-full bg-blue-500" />
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-slate-800">
                  {bus.arrival}
                </div>
                <div className="text-xs text-slate-400">Bangalore</div>
              </div>
            </div>
            <Action onClick={() => navigate("seats")} variant="secondary">
              Select
              <Icon name="chevron" className="size-4" />
            </Action>
          </div>
        ))}
      </div>
      <div className="mt-auto pt-5 text-center text-xs font-medium text-slate-400">
        Prices include all taxes and fees
      </div>
    </ScreenShell>
  )
}

function SeatsScreen({ navigate }: { navigate: (screen: Screen) => void }) {
  const [selectedSeat, setSelectedSeat] = useState("A2")
  const bookedSeats = ["A3", "B2", "C4"]
  const rows = ["A", "B", "C"]

  return (
    <ScreenShell
      screen="seats"
      title="Select Your Seat"
      subtitle="SETC Express · ₹650 per seat"
      onBack={() => navigate("results")}
    >
      <div className="mb-4 flex items-center justify-center gap-4 text-xs font-medium text-slate-500">
        <div className="flex items-center gap-1.5">
          <div className="size-3 rounded bg-white ring-1 ring-slate-300" />{" "}
          Available
        </div>
        <div className="flex items-center gap-1.5">
          <div className="size-3 rounded bg-blue-600" /> Selected
        </div>
        <div className="flex items-center gap-1.5">
          <div className="size-3 rounded bg-slate-200" /> Booked
        </div>
      </div>

      <div className="mx-auto w-full max-w-xs rounded-3xl border-2 border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-7 flex items-center justify-between border-b border-dashed border-slate-200 pb-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <Icon name="bus" className="size-4" /> FRONT
          </div>
          <div className="flex size-8 items-center justify-center rounded-full border-2 border-slate-300 text-slate-400">
            <div className="size-3 rounded-full border-2 border-current" />
          </div>
        </div>
        <div className="space-y-4">
          {rows.map((row) => (
            <div
              key={row}
              className="grid grid-cols-[1fr_1fr_0.65fr_1fr_1fr] items-center gap-3"
            >
              {[1, 2, null, 3, 4].map((number, index) => {
                if (number === null)
                  return (
                    <div
                      key={`aisle-${row}-${index}`}
                      className="text-center text-xs text-slate-300"
                    >
                      ·
                    </div>
                  )
                const seat = `${row}${number}`
                const booked = bookedSeats.includes(seat)
                const selected = selectedSeat === seat
                return (
                  <div
                    key={seat}
                    role="button"
                    tabIndex={booked ? -1 : 0}
                    aria-label={`Seat ${seat}${
                      booked
                        ? ", booked"
                        : selected
                          ? ", selected"
                          : ", available"
                    }`}
                    onClick={() => !booked && setSelectedSeat(seat)}
                    onKeyDown={(event) =>
                      event.key === "Enter" && !booked && setSelectedSeat(seat)
                    }
                    className={`flex aspect-square items-center justify-center rounded-xl text-xs font-bold transition ${
                      booked
                        ? "cursor-not-allowed bg-slate-200 text-slate-400"
                        : selected
                          ? "cursor-pointer bg-blue-600 text-white shadow-md shadow-blue-200"
                          : "cursor-pointer border border-slate-300 bg-white text-slate-600 hover:border-blue-400 hover:text-blue-600"
                    }`}
                  >
                    {seat}
                  </div>
                )
              })}
            </div>
          ))}
        </div>
      </div>

      <div className="mt-auto pt-5">
        <div className="mb-3 flex items-center justify-between rounded-2xl bg-blue-50 px-4 py-3">
          <div>
            <div className="text-xs font-medium text-slate-500">
              Selected seat
            </div>
            <div className="text-sm font-extrabold text-blue-700">
              {selectedSeat}
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs font-medium text-slate-500">Total fare</div>
            <div className="text-lg font-extrabold text-slate-900">₹650</div>
          </div>
        </div>
        <Action onClick={() => navigate("passenger")}>
          Continue
          <Icon name="chevron" className="size-4" />
        </Action>
      </div>
    </ScreenShell>
  )
}

function PassengerScreen({ navigate }: { navigate: (screen: Screen) => void }) {
  return (
    <ScreenShell
      screen="passenger"
      title="Passenger Details"
      subtitle="Enter traveller information"
      onBack={() => navigate("seats")}
    >
      <div className="mb-4 rounded-2xl bg-blue-50 px-4 py-3 text-xs font-medium leading-relaxed text-blue-700">
        Your details are securely saved for this booking only.
      </div>
      <div className="space-y-3">
        <Field label="NAME" value="Punith" icon="person" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="AGE" value="22" />
          <Field label="GENDER" value="Male" />
        </div>
        <Field label="MOBILE NUMBER" value="98765 43210" />
      </div>
      <div className="mt-5 flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
          <Icon name="shield" className="size-5" />
        </div>
        <div>
          <div className="text-sm font-bold text-slate-800">
            Booking updates
          </div>
          <div className="mt-1 text-xs leading-relaxed text-slate-500">
            Your ticket and journey alerts will be sent to this mobile number.
          </div>
        </div>
      </div>
      <Action onClick={() => navigate("payment")} className="mt-auto">
        Proceed to Payment
        <Icon name="chevron" className="size-4" />
      </Action>
    </ScreenShell>
  )
}

function PaymentScreen({ navigate }: { navigate: (screen: Screen) => void }) {
  const [method, setMethod] = useState("UPI")
  const methods = [
    {
      name: "UPI",
      detail: "Google Pay, PhonePe, Paytm",
      icon: "swap" as IconName,
    },
    {
      name: "Credit/Debit Card",
      detail: "Visa, Mastercard, RuPay",
      icon: "card" as IconName,
    },
    {
      name: "Net Banking",
      detail: "All major banks supported",
      icon: "shield" as IconName,
    },
  ]

  return (
    <ScreenShell
      screen="payment"
      title="Payment"
      subtitle="Choose a payment method"
      onBack={() => navigate("passenger")}
    >
      <div className="mb-5 rounded-3xl bg-blue-600 p-5 text-white shadow-xl shadow-blue-200">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs font-medium text-blue-100">Total fare</div>
            <div className="mt-1 text-3xl font-extrabold">₹650</div>
          </div>
          <div className="rounded-2xl bg-white/15 px-3 py-2 text-right">
            <div className="text-xs text-blue-100">Seat</div>
            <div className="font-bold">A2</div>
          </div>
        </div>
      </div>

      <div className="mb-3 text-sm font-bold text-slate-800">
        Payment options
      </div>
      <div className="space-y-3">
        {methods.map((item) => {
          const selected = method === item.name
          return (
            <div
              key={item.name}
              role="button"
              tabIndex={0}
              onClick={() => setMethod(item.name)}
              onKeyDown={(event) =>
                event.key === "Enter" && setMethod(item.name)
              }
              className={`flex cursor-pointer items-center gap-3 rounded-2xl border p-4 transition ${
                selected
                  ? "border-blue-500 bg-blue-50"
                  : "border-slate-200 bg-white hover:border-blue-200"
              }`}
            >
              <div
                className={`flex size-11 items-center justify-center rounded-xl ${
                  selected
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-500"
                }`}
              >
                <Icon name={item.icon} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-bold text-slate-800">
                  {item.name}
                </div>
                <div className="mt-0.5 truncate text-xs text-slate-400">
                  {item.detail}
                </div>
              </div>
              <div
                className={`flex size-5 items-center justify-center rounded-full border-2 ${
                  selected
                    ? "border-blue-600 bg-blue-600 text-white"
                    : "border-slate-300"
                }`}
              >
                {selected && <Icon name="check" className="size-3" />}
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-auto pt-5">
        <div className="mb-3 flex items-center justify-center gap-2 text-xs font-medium text-slate-400">
          <Icon name="shield" className="size-4" /> Secure and encrypted payment
        </div>
        <Action onClick={() => navigate("confirmation")}>
          Pay Now · ₹650
          <Icon name="chevron" className="size-4" />
        </Action>
      </div>
    </ScreenShell>
  )
}

function ConfirmationScreen({
  navigate,
}: {
  navigate: (screen: Screen) => void
}) {
  const [downloaded, setDownloaded] = useState(false)

  const downloadTicket = () => {
    const ticket = [
      "BUS TICKET",
      "Booking ID: BUS12345",
      "Passenger: Punith",
      "Bus: SETC Express",
      "Route: Chennai to Bangalore",
      "Seat: A2",
      "Date: 10 October 2026",
      "Fare: ₹650",
    ].join("\n")
    const url = URL.createObjectURL(new Blob([ticket], { type: "text/plain" }))
    const link = document.createElement("a")
    link.href = url
    link.download = "BUS12345-ticket.txt"
    link.click()
    URL.revokeObjectURL(url)
    setDownloaded(true)
  }

  const details = [
    ["Booking ID", "BUS12345"],
    ["Passenger", "Punith"],
    ["Bus", "SETC Express"],
    ["From", "Chennai"],
    ["To", "Bangalore"],
    ["Seat", "A2"],
    ["Date", "10 October 2026"],
    ["Fare", "₹650"],
  ]

  return (
    <ScreenShell
      screen="confirmation"
      title="Booking Confirmed"
      subtitle="Your ticket is ready"
    >
      <div className="mb-5 text-center">
        <div className="mx-auto flex size-20 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 ring-8 ring-emerald-50">
          <Icon name="check" className="size-10" />
        </div>
        <div className="mt-5 text-2xl font-extrabold tracking-tight text-slate-900">
          Booking Successful
        </div>
        <div className="mt-1 text-sm text-slate-500">
          Have a safe and pleasant journey!
        </div>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center gap-3 bg-blue-600 px-5 py-4 text-white">
          <div className="flex size-10 items-center justify-center rounded-xl bg-white/15">
            <Icon name="bus" />
          </div>
          <div>
            <div className="text-xs font-medium text-blue-100">E-TICKET</div>
            <div className="font-bold">Chennai → Bangalore</div>
          </div>
        </div>
        <div className="divide-y divide-slate-100 px-5">
          {details.map(([label, value]) => (
            <div
              key={label}
              className="flex items-center justify-between py-2.5"
            >
              <div className="text-xs font-medium text-slate-400">{label}</div>
              <div className="text-sm font-bold text-slate-800">{value}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-auto space-y-3 pt-5">
        {downloaded && (
          <div className="text-center text-xs font-semibold text-emerald-600">
            Ticket downloaded successfully
          </div>
        )}
        <Action onClick={downloadTicket}>
          <Icon name="download" className="size-4" />
          Download Ticket
        </Action>
        <Action onClick={() => navigate("home")} variant="secondary">
          Book Another Ticket
        </Action>
      </div>
    </ScreenShell>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home")

  const navigate = (nextScreen: Screen) => {
    setScreen(nextScreen)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <main className="min-h-dvh bg-slate-100 text-slate-900 antialiased">
      <div className="mx-auto min-h-dvh w-full max-w-md overflow-hidden bg-slate-50 shadow-2xl">
        {screen === "home" && <HomeScreen navigate={navigate} />}
        {screen === "results" && <ResultsScreen navigate={navigate} />}
        {screen === "seats" && <SeatsScreen navigate={navigate} />}
        {screen === "passenger" && <PassengerScreen navigate={navigate} />}
        {screen === "payment" && <PaymentScreen navigate={navigate} />}
        {screen === "confirmation" && (
          <ConfirmationScreen navigate={navigate} />
        )}
      </div>
    </main>
  )
}
