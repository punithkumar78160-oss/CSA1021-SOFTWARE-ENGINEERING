import { useEffect, useState } from "react";

type Screen =
  | "review"
  | "designA"
  | "designB"
  | "product"
  | "cart"
  | "checkout"
  | "confirmation"
  | "feedback"
  | "approval";

type IconName =
  | "arrow"
  | "bag"
  | "beauty"
  | "cart"
  | "category"
  | "check"
  | "chevron"
  | "electronics"
  | "fashion"
  | "grocery"
  | "heart"
  | "home"
  | "minus"
  | "plus"
  | "profile"
  | "search"
  | "shield"
  | "star";

const headphones =
  "https://images.unsplash.com/photo-1641048930621-ab5d225ae5b0?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900";
const sneakers =
  "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900";
const watch =
  "https://images.unsplash.com/photo-1714218707578-92465ec6fa8b?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900";
const tech =
  "https://images.unsplash.com/photo-1785239232672-88ae9c285ce8?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000";

const paths: Record<IconName, React.ReactNode> = {
  arrow: <path d="m15 18-6-6 6-6" />,
  bag: <><path d="M6 8h12l-1 12H7L6 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
  beauty: <><path d="M9 7h6v13H9z" /><path d="M10 7V4h4v3M9 12h6" /></>,
  cart: <><path d="M3 4h2l2 11h10l2-7H6" /><circle cx="9" cy="19" r="1" /><circle cx="17" cy="19" r="1" /></>,
  category: <><rect x="4" y="4" width="6" height="6" rx="1" /><rect x="14" y="4" width="6" height="6" rx="1" /><rect x="4" y="14" width="6" height="6" rx="1" /><rect x="14" y="14" width="6" height="6" rx="1" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  chevron: <path d="m9 18 6-6-6-6" />,
  electronics: <><rect x="5" y="4" width="14" height="16" rx="3" /><path d="M10 17h4" /></>,
  fashion: <><path d="m8 7-4 4 3 3 2-2v8h6v-8l2 2 3-3-4-4-2 2h-4L8 7Z" /></>,
  grocery: <><path d="M4 9h16l-2 11H6L4 9Z" /><path d="M8 9a4 4 0 0 1 8 0" /></>,
  heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
  home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
  minus: <path d="M5 12h14" />,
  plus: <path d="M12 5v14M5 12h14" />,
  profile: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  shield: <><path d="M12 22s8-3 8-10V5l-8-3-8 3v7c0 7 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
  star: <path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3-5.8 3 1.1-6.5-4.7-4.6 6.5-.9L12 2.5Z" />,
};

function Icon({ name, size = 20, filled = false }: { name: IconName; size?: number; filled?: boolean }) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

const feedbackItems = ["Easy to use", "Attractive", "Easy navigation", "Clear product information"];

export default function App() {
  const [screen, setScreen] = useState<Screen>("review");
  const [source, setSource] = useState<"A" | "B">("A");
  const [quantity, setQuantity] = useState(1);
  const [selectedFeedback, setSelectedFeedback] = useState<string[]>(feedbackItems);
  const [approved, setApproved] = useState<"A" | "B">("A");

  const navigate = (next: Screen) => setScreen(next);
  const chooseDesign = (design: "A" | "B") => {
    setSource(design);
    navigate(design === "A" ? "designA" : "designB");
  };

  useEffect(() => {
    document.querySelector(".phone-scroll")?.scrollTo({ top: 0, behavior: "smooth" });
  }, [screen]);

  const openProduct = (design: "A" | "B") => {
    setSource(design);
    navigate("product");
  };

  return (
    <main className="app-shell">
      <div className="prototype-label">
        <span>Interactive prototype</span>
        <strong>{screen === "review" ? "UI comparison" : `Design ${source} flow`}</strong>
      </div>
      <section className="phone-frame" aria-label="ShopEasy mobile commerce prototype">
        <div className="phone-scroll">
          {screen === "review" && <ReviewScreen onChoose={chooseDesign} />}
          {screen === "designA" && (
            <DesignA onProduct={() => openProduct("A")} onFeedback={() => navigate("feedback")} />
          )}
          {screen === "designB" && (
            <DesignB onProduct={() => openProduct("B")} onFeedback={() => navigate("feedback")} />
          )}
          {screen === "product" && (
            <ProductDetails
              source={source}
              quantity={quantity}
              onQuantity={setQuantity}
              onBack={() => chooseDesign(source)}
              onCart={() => navigate("cart")}
              onBuy={() => navigate("checkout")}
            />
          )}
          {screen === "cart" && (
            <Cart quantity={quantity} onQuantity={setQuantity} onBack={() => navigate("product")} onCheckout={() => navigate("checkout")} />
          )}
          {screen === "checkout" && (
            <Checkout quantity={quantity} onBack={() => navigate("cart")} onPlaceOrder={() => navigate("confirmation")} />
          )}
          {screen === "confirmation" && (
            <OrderConfirmation onContinue={() => chooseDesign(source)} onFeedback={() => navigate("feedback")} />
          )}
          {screen === "feedback" && (
            <Feedback
              selected={selectedFeedback}
              onToggle={(item) =>
                setSelectedFeedback((current) =>
                  current.includes(item) ? current.filter((value) => value !== item) : [...current, item],
                )
              }
              onBack={() => chooseDesign(source)}
              onApprove={(design) => {
                setApproved(design);
                navigate("approval");
              }}
              onChanges={() => navigate("review")}
            />
          )}
          {screen === "approval" && (
            <Approval design={approved} onContinue={() => chooseDesign(approved)} onRestart={() => navigate("review")} />
          )}
        </div>
      </section>
      <p className="prototype-hint">Select any primary action to navigate the flow</p>
    </main>
  );
}

function ReviewScreen({ onChoose }: { onChoose: (design: "A" | "B") => void }) {
  return (
    <div className="review-screen screen">
      <header className="review-header">
        <div className="brand-mark light"><Icon name="bag" size={19} /></div>
        <span>ShopEasy · Concept review</span>
      </header>
      <div className="review-intro">
        <p className="eyebrow light-text">Stakeholder review</p>
        <h1>E-Commerce App – UI Review</h1>
        <p>Compare two distinct directions for the mobile shopping experience.</p>
      </div>
      <div className="comparison-cards">
        <article className="concept-card concept-a">
          <div className="concept-top">
            <span className="option-pill">Option A</span>
            <span className="concept-index">01</span>
          </div>
          <div className="concept-preview grid-preview">
            <div className="preview-search" />
            <div className="preview-chips"><i /><i /><i /><i /></div>
            <div className="preview-grid"><i /><i /><i /><i /></div>
          </div>
          <h2>Modern Grid</h2>
          <p>Clean, familiar and product-first.</p>
          <button className="review-button blue" onClick={() => onChoose("A")}>
            View Design A <Icon name="arrow" size={18} />
          </button>
        </article>
        <article className="concept-card concept-b">
          <div className="concept-top">
            <span className="option-pill dark">Option B</span>
            <span className="concept-index">02</span>
          </div>
          <div className="concept-preview list-preview">
            <div className="preview-banner" />
            <div className="preview-row"><i /><span /></div>
            <div className="preview-row"><i /><span /></div>
          </div>
          <h2>Banner &amp; List</h2>
          <p>Editorial, bold and offer-led.</p>
          <button className="review-button ink" onClick={() => onChoose("B")}>
            View Design B <Icon name="arrow" size={18} />
          </button>
        </article>
      </div>
    </div>
  );
}

function SearchBar({ warm = false }: { warm?: boolean }) {
  return (
    <button className={`search-bar ${warm ? "warm" : ""}`} aria-label="Search products">
      <Icon name="search" size={19} />
      <span>Search products</span>
    </button>
  );
}

const categories: { name: string; icon: IconName }[] = [
  { name: "Electronics", icon: "electronics" },
  { name: "Fashion", icon: "fashion" },
  { name: "Grocery", icon: "grocery" },
  { name: "Beauty", icon: "beauty" },
];

function DesignA({ onProduct, onFeedback }: { onProduct: () => void; onFeedback: () => void }) {
  return (
    <div className="screen design-a">
      <header className="shop-header">
        <div className="logo"><span><Icon name="bag" size={18} /></span>ShopEasy</div>
        <button className="icon-button" aria-label="Shopping cart"><Icon name="cart" /></button>
      </header>
      <section className="welcome-row">
        <div><p>Good morning</p><h1>Find your favorite</h1></div>
        <div className="avatar">AL</div>
      </section>
      <SearchBar />
      <section>
        <div className="section-heading"><h2>Categories</h2><button>See all</button></div>
        <div className="category-grid">
          {categories.map((category) => (
            <button className="category-item" key={category.name}>
              <span><Icon name={category.icon} size={21} /></span>{category.name}
            </button>
          ))}
        </div>
      </section>
      <section>
        <div className="section-heading"><h2>Popular picks</h2><button>See all</button></div>
        <div className="product-grid">
          <ProductTile image={headphones} name="Studio Headphones" price="$129.00" rating="4.8" onClick={onProduct} />
          <ProductTile image={sneakers} name="Air Street Sneakers" price="$94.00" rating="4.6" onClick={onProduct} />
          <ProductTile image={watch} name="Slate Watch" price="$189.00" rating="4.7" onClick={onProduct} />
          <ProductTile image={tech} name="Everyday Tech Kit" price="$79.00" rating="4.5" onClick={onProduct} />
        </div>
      </section>
      <button className="feedback-link" onClick={onFeedback}>Review this design <Icon name="chevron" size={17} /></button>
      <BottomNav active="home" />
    </div>
  );
}

function ProductTile({ image, name, price, rating, onClick }: { image: string; name: string; price: string; rating: string; onClick: () => void }) {
  return (
    <button className="product-tile" onClick={onClick}>
      <span className="tile-image"><img src={image} alt="" /><i><Icon name="heart" size={15} /></i></span>
      <span className="tile-name">{name}</span>
      <span className="tile-meta"><strong>{price}</strong><small><Icon name="star" size={12} filled />{rating}</small></span>
    </button>
  );
}

function DesignB({ onProduct, onFeedback }: { onProduct: () => void; onFeedback: () => void }) {
  return (
    <div className="screen design-b">
      <header className="b-header">
        <button className="b-menu" aria-label="Open menu"><i /><i /></button>
        <div className="b-logo">SHOPEASY<span>CURATED GOODS</span></div>
        <button className="bag-button" aria-label="Shopping bag"><Icon name="bag" /><span>1</span></button>
      </header>
      <SearchBar warm />
      <button className="promo-banner" onClick={onProduct}>
        <img src={sneakers} alt="Red and white sneaker collection" />
        <span className="promo-overlay" />
        <span className="promo-copy"><small>NEW SEASON</small><strong>Move in style.</strong><em>Up to 30% off selected shoes</em><b>Shop the edit <Icon name="arrow" size={16} /></b></span>
      </button>
      <div className="b-categories">
        {["New in", "Women", "Men", "Home"].map((item, index) => <button className={index === 0 ? "active" : ""} key={item}>{item}</button>)}
      </div>
      <section>
        <div className="b-section-heading"><div><small>HANDPICKED</small><h2>Featured products</h2></div><button>View all</button></div>
        <div className="horizontal-products">
          <HorizontalProduct image={headphones} name="Studio Pro Headphones" category="Audio · New arrival" price="$129" onClick={onProduct} />
          <HorizontalProduct image={watch} name="Slate Everyday Watch" category="Accessories · Bestseller" price="$189" onClick={onProduct} />
          <HorizontalProduct image={tech} name="The Essential Tech Kit" category="Lifestyle · Online only" price="$79" onClick={onProduct} />
        </div>
      </section>
      <button className="b-feedback" onClick={onFeedback}><span>Share stakeholder feedback</span><Icon name="chevron" size={18} /></button>
      <nav className="b-nav">
        <button className="active"><Icon name="home" size={19} /><span>Discover</span></button>
        <button><Icon name="search" size={19} /><span>Browse</span></button>
        <button><Icon name="heart" size={19} /><span>Saved</span></button>
        <button><Icon name="profile" size={19} /><span>Account</span></button>
      </nav>
    </div>
  );
}

function HorizontalProduct({ image, name, category, price, onClick }: { image: string; name: string; category: string; price: string; onClick: () => void }) {
  return (
    <button className="horizontal-product" onClick={onClick}>
      <img src={image} alt="" />
      <span><small>{category}</small><strong>{name}</strong><b>{price}</b></span>
      <i><Icon name="chevron" size={18} /></i>
    </button>
  );
}

function BottomNav({ active }: { active: string }) {
  const items: { label: string; icon: IconName }[] = [
    { label: "Home", icon: "home" }, { label: "Categories", icon: "category" },
    { label: "Cart", icon: "cart" }, { label: "Profile", icon: "profile" },
  ];
  return <nav className="bottom-nav">{items.map((item) => <button className={active === item.label.toLowerCase() ? "active" : ""} key={item.label}><Icon name={item.icon} size={20} /><span>{item.label}</span></button>)}</nav>;
}

function TopBar({ title, onBack, action }: { title: string; onBack: () => void; action?: React.ReactNode }) {
  return <header className="top-bar"><button className="back-button" onClick={onBack} aria-label="Go back"><Icon name="arrow" /></button><h1>{title}</h1>{action || <span className="bar-spacer" />}</header>;
}

function ProductDetails({ source, quantity, onQuantity, onBack, onCart, onBuy }: { source: "A" | "B"; quantity: number; onQuantity: (n: number) => void; onBack: () => void; onCart: () => void; onBuy: () => void }) {
  return (
    <div className={`screen details-screen source-${source.toLowerCase()}`}>
      <TopBar title="Product details" onBack={onBack} action={<button className="back-button" aria-label="Save product"><Icon name="heart" /></button>} />
      <div className="detail-image"><img src={headphones} alt="Black Studio Pro wireless headphones" /><span>BESTSELLER</span><div className="image-dots"><i /><i /><i /></div></div>
      <section className="detail-content">
        <p className="detail-brand">AUDIOHOUSE</p>
        <h2>Studio Pro Wireless Headphones</h2>
        <div className="detail-rating"><span><Icon name="star" size={15} filled /> 4.8</span><button>248 reviews</button></div>
        <div className="detail-price"><strong>$129.00</strong><small>$159.00</small><span>Save 19%</span></div>
        <div className="detail-divider" />
        <h3>Description</h3>
        <p className="description">Immersive sound meets all-day comfort. Studio Pro features active noise cancellation, rich spatial audio and up to 40 hours of wireless listening.</p>
        <div className="quantity-row"><span><b>Quantity</b><small>In stock · Ready to ship</small></span><Quantity value={quantity} onChange={onQuantity} /></div>
      </section>
      <div className="detail-actions"><button className="secondary-action" onClick={onCart}><Icon name="cart" size={19} /> Add to Cart</button><button className="primary-action" onClick={onBuy}>Buy Now</button></div>
    </div>
  );
}

function Quantity({ value, onChange }: { value: number; onChange: (n: number) => void }) {
  return <div className="quantity"><button onClick={() => onChange(Math.max(1, value - 1))} aria-label="Decrease quantity"><Icon name="minus" size={16} /></button><span>{value}</span><button onClick={() => onChange(value + 1)} aria-label="Increase quantity"><Icon name="plus" size={16} /></button></div>;
}

function Cart({ quantity, onQuantity, onBack, onCheckout }: { quantity: number; onQuantity: (n: number) => void; onBack: () => void; onCheckout: () => void }) {
  const subtotal = 129 * quantity;
  return (
    <div className="screen cart-screen">
      <TopBar title={`My cart (${quantity})`} onBack={onBack} />
      <div className="delivery-note"><span><Icon name="bag" size={20} /></span><p><b>Free delivery unlocked</b><small>Your order qualifies for free standard shipping.</small></p></div>
      <article className="cart-item">
        <img src={headphones} alt="Studio Pro wireless headphones" />
        <div><small>AUDIOHOUSE</small><h2>Studio Pro Wireless Headphones</h2><p>Color: Midnight Black</p><strong>$129.00</strong><Quantity value={quantity} onChange={onQuantity} /></div>
      </article>
      <button className="coupon"><span><Icon name="plus" size={18} /> Add a promo code</span><Icon name="chevron" size={18} /></button>
      <section className="summary-card">
        <h2>Order summary</h2>
        <p><span>Subtotal</span><strong>${subtotal.toFixed(2)}</strong></p>
        <p><span>Delivery</span><strong className="success-text">Free</strong></p>
        <div />
        <p className="total"><span>Total</span><strong>${subtotal.toFixed(2)}</strong></p>
        <small>Taxes included where applicable</small>
      </section>
      <div className="sticky-action"><button className="primary-action full" onClick={onCheckout}>Proceed to Checkout <Icon name="arrow" size={18} /></button><p><Icon name="shield" size={14} /> Secure checkout</p></div>
    </div>
  );
}

function Checkout({ quantity, onBack, onPlaceOrder }: { quantity: number; onBack: () => void; onPlaceOrder: () => void }) {
  const total = 129 * quantity;
  return (
    <div className="screen checkout-screen">
      <TopBar title="Checkout" onBack={onBack} />
      <div className="checkout-progress"><span className="done"><Icon name="check" size={12} /></span><i /><span className="active">2</span><i /><span>3</span></div>
      <section className="checkout-block">
        <div className="block-heading"><div><span>1</span><h2>Delivery address</h2></div><button>Edit</button></div>
        <article className="choice-card selected"><i><Icon name="check" size={13} /></i><div><b>Alex Morgan</b><p>485 Market Street, Apt 12B<br />San Francisco, CA 94105</p><small>+1 (415) 555-0132</small></div></article>
      </section>
      <section className="checkout-block">
        <div className="block-heading"><div><span>2</span><h2>Payment method</h2></div><button>Change</button></div>
        <article className="choice-card selected"><i><Icon name="check" size={13} /></i><div><b>•••• •••• •••• 4242</b><p>Visa · Expires 09/28</p></div><strong>VISA</strong></article>
      </section>
      <section className="checkout-block order-block">
        <div className="block-heading"><div><span>3</span><h2>Order summary</h2></div></div>
        <div className="mini-product"><img src={headphones} alt="" /><span><b>Studio Pro Headphones</b><small>Qty: {quantity}</small></span><strong>${total.toFixed(2)}</strong></div>
        <div className="summary-lines"><p><span>Subtotal</span><b>${total.toFixed(2)}</b></p><p><span>Delivery</span><b className="success-text">Free</b></p><p className="total"><span>Total</span><b>${total.toFixed(2)}</b></p></div>
      </section>
      <div className="sticky-action checkout-action"><button className="primary-action full" onClick={onPlaceOrder}>Place Order · ${total.toFixed(2)}</button><p><Icon name="shield" size={14} /> Your payment information is encrypted</p></div>
    </div>
  );
}

function OrderConfirmation({ onContinue, onFeedback }: { onContinue: () => void; onFeedback: () => void }) {
  return (
    <div className="screen confirmation-screen">
      <div className="success-icon"><Icon name="check" size={34} /></div>
      <p className="eyebrow">ORDER #SE-20481</p>
      <h1>Your order is confirmed.</h1>
      <p>Thanks, Alex. We’re preparing your order and will let you know when it’s on the way.</p>
      <div className="arrival-card"><small>ESTIMATED ARRIVAL</small><strong>Friday, 17 January</strong><span>Standard delivery · Free</span></div>
      <div className="confirmation-product"><img src={headphones} alt="" /><span><b>Studio Pro Headphones</b><small>Midnight Black · Qty 1</small></span><strong>$129</strong></div>
      <button className="primary-action full" onClick={onContinue}>Continue Shopping</button>
      <button className="text-action" onClick={onFeedback}>Give stakeholder feedback</button>
    </div>
  );
}

function Feedback({ selected, onToggle, onBack, onApprove, onChanges }: { selected: string[]; onToggle: (item: string) => void; onBack: () => void; onApprove: (design: "A" | "B") => void; onChanges: () => void }) {
  return (
    <div className="screen feedback-screen">
      <TopBar title="Stakeholder Feedback" onBack={onBack} />
      <header className="feedback-intro"><p className="eyebrow">UI DIRECTION REVIEW</p><h2>Which experience works best?</h2><p>Select the qualities that apply, then approve a design direction.</p></header>
      <div className="design-tabs"><button className="active"><span>A</span><b>Design A</b><small>Modern Grid</small></button><button><span>B</span><b>Design B</b><small>Banner &amp; List</small></button></div>
      <section className="criteria">
        <div className="section-heading"><h2>Feedback options</h2><small>{selected.length} selected</small></div>
        {feedbackItems.map((item) => {
          const active = selected.includes(item);
          return <button className={active ? "selected" : ""} onClick={() => onToggle(item)} key={item}><span>{active && <Icon name="check" size={14} />}</span>{item}</button>;
        })}
      </section>
      <label className="comment-box"><span>Additional notes <small>Optional</small></span><textarea placeholder="Share feedback with the product team..." /></label>
      <div className="approval-actions"><button className="primary-action full" onClick={() => onApprove("A")}>Approve Design A</button><button className="secondary-action full" onClick={() => onApprove("B")}>Approve Design B</button><button className="text-action" onClick={onChanges}>Request Changes</button></div>
    </div>
  );
}

function Approval({ design, onContinue, onRestart }: { design: "A" | "B"; onContinue: () => void; onRestart: () => void }) {
  return (
    <div className="screen approval-screen">
      <div className="approval-art">
        <span className="spark one" /><span className="spark two" /><span className="spark three" />
        <div className="approval-check"><Icon name="check" size={38} /></div>
      </div>
      <p className="eyebrow">REVIEW COMPLETE</p>
      <h1>Final UI Approval</h1>
      <p className="approval-message">Design approved by stakeholders</p>
      <article className="approved-card">
        <div className={`approved-preview approved-${design.toLowerCase()}`}><span>{design}</span><i /><i /><i /></div>
        <div><small>APPROVED DESIGN</small><h2>Design {design}</h2><p>{design === "A" ? "Modern Grid" : "Banner & List"}</p></div>
        <span className="approved-badge"><Icon name="check" size={14} /> Approved</span>
      </article>
      <div className="approval-meta"><span><small>STATUS</small><b>Ready for handoff</b></span><i /><span><small>DECISION</small><b>Stakeholder approved</b></span></div>
      <button className="primary-action full" onClick={onContinue}>Continue Shopping <Icon name="arrow" size={18} /></button>
      <button className="text-action" onClick={onRestart}>Back to design comparison</button>
    </div>
  );
}
